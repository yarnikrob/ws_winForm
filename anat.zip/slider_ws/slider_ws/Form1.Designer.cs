﻿namespace slider_ws
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.slider3 = new System.Windows.Forms.PictureBox();
            this.slider2 = new System.Windows.Forms.PictureBox();
            this.slider1 = new System.Windows.Forms.PictureBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.slider3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slider2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slider1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(472, 59);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.Controls.Add(this.button1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 218);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(472, 62);
            this.panel2.TabIndex = 0;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.slider3);
            this.panel3.Controls.Add(this.slider2);
            this.panel3.Controls.Add(this.slider1);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 59);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(472, 159);
            this.panel3.TabIndex = 0;
            // 
            // slider3
            // 
            this.slider3.Dock = System.Windows.Forms.DockStyle.Right;
            this.slider3.Image = ((System.Drawing.Image)(resources.GetObject("slider3.Image")));
            this.slider3.Location = new System.Drawing.Point(322, 0);
            this.slider3.Name = "slider3";
            this.slider3.Size = new System.Drawing.Size(150, 159);
            this.slider3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.slider3.TabIndex = 2;
            this.slider3.TabStop = false;
            this.slider3.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // slider2
            // 
            this.slider2.Image = ((System.Drawing.Image)(resources.GetObject("slider2.Image")));
            this.slider2.Location = new System.Drawing.Point(157, 0);
            this.slider2.Name = "slider2";
            this.slider2.Size = new System.Drawing.Size(165, 159);
            this.slider2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.slider2.TabIndex = 1;
            this.slider2.TabStop = false;
            this.slider2.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // slider1
            // 
            this.slider1.Dock = System.Windows.Forms.DockStyle.Left;
            this.slider1.Image = ((System.Drawing.Image)(resources.GetObject("slider1.Image")));
            this.slider1.Location = new System.Drawing.Point(0, 0);
            this.slider1.Name = "slider1";
            this.slider1.Size = new System.Drawing.Size(157, 159);
            this.slider1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.slider1.TabIndex = 0;
            this.slider1.TabStop = false;
            this.slider1.Click += new System.EventHandler(this.slider_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 2000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // button1
            // 
            this.button1.AutoEllipsis = true;
            this.button1.BackColor = System.Drawing.Color.Maroon;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(322, 20);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(138, 30);
            this.button1.TabIndex = 3;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(472, 280);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.panel2.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.slider3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slider2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slider1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox slider1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.PictureBox slider3;
        private System.Windows.Forms.PictureBox slider2;
        private System.Windows.Forms.Button button1;
    }
}

