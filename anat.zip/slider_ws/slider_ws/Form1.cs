﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace slider_ws
{
    public partial class Form1 : Form
    {

        


        public Form1()
        {
            InitializeComponent();
        }

        private int iNumber1 = 1015;
        private int iNumber2 = 1016;
        private int iNumber3 = 1017;

        private void LoadNextImage()
        {

            if (iNumber1 == 1021) {
                iNumber1 = 1015;
            }
            slider1.ImageLocation = string.Format(@"images/{0}.jpg", iNumber1);
            iNumber1 += 1;

           /* if (iNumber2 == 1022)
            {
                iNumber2 = 1016;
            }
            slider2.ImageLocation = string.Format(@"images/{0}.jpg", iNumber2);
            iNumber2 += 3;

            if (iNumber3 == 1023)
            {
                iNumber3 = 1017;
            }
            slider3.ImageLocation = string.Format(@"images/{0}.jpg", iNumber2);
            iNumber3 += 3;*/
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            LoadNextImage();

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void slider_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Owner.Show();
            this.Close();
        }
    }
}
