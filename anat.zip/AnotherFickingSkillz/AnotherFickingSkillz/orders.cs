﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AnotherFickingSkillz
{
    public partial class orders : Form
    {
        public orders()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var ConstructOF = new OF();
            this.Hide();
            ConstructOF.Show(this);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var OL = new OLF();
            this.Hide();
            OL.Show(this);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Owner.Show();
            this.Close();
        }

        private void orders_Load(object sender, EventArgs e)
        {

        }
    }
}
