﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace AnotherFickingSkillz
{
    class DB
    {


        private static string connectionString = @"Data Source=DESKTOP-HCIJKBO\SQLEXPRESSKONSPI;Initial Catalog=sess1_ws;Integrated Security=True";

        public static SqlConnection connection = new SqlConnection(connectionString);

        public static SqlDataReader select(string a, string b)
        {
            string commandString = "SELECT [" + b + "]." + a + " FROM [" + b + "]";
            connection.Open();
            SqlCommand command = new SqlCommand(commandString, connection);
            SqlDataReader answer = command.ExecuteReader();
            return answer;
        }

        public static SqlDataReader selectwhere(string a, string b, string c)
        {
            string commandString = "SELECT [" + b + "]." + a + " FROM [" + b + "] WHERE " + c;
            connection.Open();
            SqlCommand command = new SqlCommand(commandString, connection);
            SqlDataReader answer = command.ExecuteReader();
            return answer;
        }


        public static void insert(string a, string b)
        {
            try
            {
                string commandString = "INSERT INTO " + a + " VALUES " + b;
                connection.Open();
                SqlCommand command = new SqlCommand(commandString, connection);
                command.ExecuteNonQuery();
                connection.Close();
            }
            catch
            {
                
            }
        }

        public static void update(string a, string b, string c)
        {
            string commandString = "UPDATE " + a + " SET " + b + " WHERE " + c;
            connection.Open();
            SqlCommand command = new SqlCommand(commandString, connection);
            command.ExecuteNonQuery();
            connection.Close();
        }
    }
}
