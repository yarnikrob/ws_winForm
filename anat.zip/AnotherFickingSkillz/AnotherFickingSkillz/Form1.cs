﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using AnotherFickingSkillz.Properties;
using System.Data.SqlClient;

namespace AnotherFickingSkillz
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            textBox1.Text = Settings.Default["NameLog"].ToString();
            textBox2.Text = Settings.Default["NamePass"].ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                Settings.Default["NameLog"] = textBox1.Text;
                Settings.Default["NamePass"] = textBox2.Text;
                Settings.Default.Save();
            }
            else {
                Settings.Default["NameLog"] = "";
                Settings.Default["NamePass"] = "";
                Settings.Default.Save();
            }






            var answer = DB.selectwhere("*", "useridinty", "(Login = N'" + textBox1.Text + "') AND (Password = N'" + textBox2.Text + "')");
            if (answer.Read())
            {

                Data.Login = Convert.ToString(answer[0]);
                Data.Password = Convert.ToString(answer[1]);
                Data.Role = Convert.ToChar(answer[2]);
                Data.Name = Convert.ToString(answer[3]);

                MessageBox.Show("Приветствую тебя, " + Data.Name);
                DB.connection.Close();
                switch (Data.Role)
                {
                    case 'O':
                        var OForm = new orders();
                        this.Hide();
                        OForm.Show(this);
                        break;
                    case 'M':
                        var MForm = new MF();
                        this.Hide();
                        MForm.Show(this);
                        break;
                    case 'C':
                        var CForm = new CF();
                        this.Hide();
                        CForm.Show(this);
                        break;
                    case 'D':
                        var AForm = new AF();
                        this.Hide();
                        AForm.Show(this);
                        break;
                }
            }


            else
            {
                MessageBox.Show("Неправильно введён логин или пароль");
                DB.connection.Close();
            }
            }

        private void button2_Click(object sender, EventArgs e)
        {
            var regForm = new reg();
            this.Hide();
            regForm.Show(this);
        }
    }
}
