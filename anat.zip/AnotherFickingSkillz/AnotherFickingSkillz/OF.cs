﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AnotherFickingSkillz
{
    public partial class OF : Form
    {
        String[] arr1 = { "Ткань 1", "Ткань 2", "Ткань 3", "Ткань 4" };
        String[] arr2 = { "Фарнитура1", "Фарнитура2", "Фарнитура3", "Фарнитура4" };
        String[] arr3 = { "Окантовка1", "Окантовка2", "Окантовка3", "Окантовка4" };

        List<String[]> listStr = new List<string[]>();

        private void OF_Load(object sender, EventArgs e)
        {
            listStr.Add(arr1);
            listStr.Add(arr2);
            listStr.Add(arr3);
        }

        public OF()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Owner.Show();
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (comboBox1.SelectedIndex == 0) {
                    switch (listBox1.SelectedIndex)
                    {
                        case 0:
                            MessageBox.Show("Ns gblfhf!");
                            pictureBox1.Image = Image.FromFile("C:/Users/Конспиратор/Desktop/AnotherFickingSkillz/AnotherFickingSkillz/1015.jpg");
                            break;
                        case 1:
                            MessageBox.Show("Я - case №2");
                            pictureBox1.Image = Image.FromFile("C:/Users/Конспиратор/Desktop/AnotherFickingSkillz/AnotherFickingSkillz/1016.jpg");
                            break;
                        case 2:
                            MessageBox.Show("Я - case №3");
                            pictureBox1.Image = Image.FromFile("C:/Users/Конспиратор/Desktop/AnotherFickingSkillz/AnotherFickingSkillz/1017.jpg");
                            break;
                        case 3:
                            MessageBox.Show("Я - case №4");
                            pictureBox1.Image = Image.FromFile("C:/Users/Конспиратор/Desktop/AnotherFickingSkillz/AnotherFickingSkillz/1018.jpg");

                            break;
                        default:
                            MessageBox.Show("Я ушлепок");
                            break;
                    } }

                } 
            catch (System.IO.FileNotFoundException ex) {
                MessageBox.Show("Что то пошло не так");
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            listBox1.Items.AddRange(listStr[comboBox1.SelectedIndex]);
        }
    }
}
