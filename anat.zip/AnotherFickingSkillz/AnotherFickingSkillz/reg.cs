﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace AnotherFickingSkillz
{
    public partial class reg : Form
    {
        public reg()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((textBox1.Text == "") || (textBox2.Text == "") || (textBox3.Text == "") || (textBox4.Text == "") || (comboBox1.Text == ""))
            {
                MessageBox.Show("Заполните все поля!");
            }
            else if(textBox2.Text == textBox3.Text) {

                string comBox = comboBox1.Text;
                string rolee;
                switch (comBox)
                {
                    case "Заказчик":
                        rolee = "O";
                        DB.insert("[useridinty] (Login, Password, Role, Name)", "(N'" + textBox1.Text + "', N'" + textBox2.Text + "', N'" + rolee + "', N'" + textBox4.Text + "')");
                        MessageBox.Show("Регистрация прошла успешно!");
                        Owner.Show();
                        this.Close();
                        break;
                    case "Менеджер":
                        rolee = "M";
                        DB.insert("[useridinty] (Login, Password, Role, Name)", "(N'" + textBox1.Text + "', N'" + textBox2.Text + "', N'" + rolee + "', N'" + textBox4.Text + "')");
                        MessageBox.Show("Регистрация прошла успешно!");
                        Owner.Show();
                        this.Close();
                        break;
                    case "Кладовщик":
                        rolee = "C";
                        DB.insert("[useridinty] (Login, Password, Role, Name)", "(N'" + textBox1.Text + "', N'" + textBox2.Text + "', N'" + rolee + "', N'" + textBox4.Text + "')");
                        MessageBox.Show("Регистрация прошла успешно!");
                        Owner.Show();
                        this.Close();
                        break;
                    case "Дирекция":
                        rolee = "D";
                        DB.insert("[useridinty] (Login, Password, Role, Name)", "(N'" + textBox1.Text + "', N'" + textBox2.Text + "', N'" + rolee + "', N'" + textBox4.Text + "')");
                        MessageBox.Show("Регистрация прошла успешно!");
                        Owner.Show();
                        this.Close();
                        break;
                }
                }
            else
            {
                MessageBox.Show("Пороли не совподают");
            }
            }

        private void button2_Click(object sender, EventArgs e)
        {
            Owner.Show();
            this.Close();
        }
    }
    }
